const express = require('express');
const app =express()
const path = require('path')
const router = express.Router()
const port = 3000;

router
    .route('/')
    .get((req,res)=>res.sendFile(path.resolve('html/categ.html')))
    .post((req,res)=> res.send("POST"));

module.exports= router;