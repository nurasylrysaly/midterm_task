const express = require('express')
const app = express()
const port = 3000;

app.set('view engine', 'ejs');
app.set('view', './view');
app.get('main', (req,res,next)=>(
    res.render("main")
));
app.get('regis', (req,res,next)=>(
    res.render("regis")
));
app.get('categ', (req,res,next)=>(
    res.render("categ")
));

app.use("/main",require('./routes/root'))
app.use("/categ",require('./routes/categ'))
app.use("/regis",require('./routes/regis'))





/*app.get('/',((req, res) => {
    res.sendFile(__dirname+'/html/main.html')
}))

app.get('/categ',((req, res) => {
    res.sendFile(__dirname+'/html/categ.html')
}))


app.get('/regis',((req, res) => {
    res.sendFile(__dirname+'/html/regis.html')
}))*/


app.listen(port, () =>
    console.log(`App listening at http://localhost:${port}`)
);
